﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _60353_MMA22_project2
{
     class product
    {
        public string type;
        public string id;
        public string model;
        public string brand;
        public int price;
        
    }
}
