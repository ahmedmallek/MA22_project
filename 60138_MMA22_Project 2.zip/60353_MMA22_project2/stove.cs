﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _60353_MMA22_project2
{
    class stove:product
    {
        public int  number_of_heaters;
        public bool oven;
        public bool gas;
      
        public string data()
        {
            return brand + "|" + model + "|" + id + "|" + number_of_heaters + "|" + oven + "|" + gas + "|" + price;
        }
    }
}
