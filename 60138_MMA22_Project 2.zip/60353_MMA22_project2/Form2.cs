﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace _60353_MMA22_project2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void back_btn_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            this.Hide();
            f1.ShowDialog();
            this.Close();
        }

        private void proceed_btn_Click(object sender, EventArgs e)
        {
            if (type_box.SelectedItem == "tv") { add_tv_box.Enabled = true; add_fridge_box.Enabled = false; add_stove_box.Enabled = false; }
            else if (type_box.SelectedItem == "fridge") { add_fridge_box.Enabled = true; add_tv_box.Enabled = false; add_stove_box.Enabled = false; }
            else if (type_box.SelectedItem == "stove") { add_stove_box.Enabled = true; add_tv_box.Enabled = false; add_fridge_box.Enabled = false; }
        }

        private void add_tv_btn_Click(object sender, EventArgs e)
        {
            try
            {
                if (idtb.Text.Length == 0) { MessageBox.Show("id should not be empty"); }
                else if (brandtb.Text.Length == 0) { MessageBox.Show("brand should not be empty"); }
                else if (modeltb.Text.Length == 0) { MessageBox.Show("model should not be empty"); }
                else if (pricetb.Text.Length == 0) { MessageBox.Show("price should not be empty"); }
                else if (sizetb.Text.Length == 0) { MessageBox.Show("size should not be empty"); }
                else if (respond_time_tb.Text.Length == 0) { MessageBox.Show("respond time should not be empty"); }
                else
            {
               
                    tv tv1 = new tv();
                    tv1.id = idtb.Text;
                    tv1.brand = brandtb.Text;
                    tv1.model = modeltb.Text;
                    tv1.price = Convert.ToInt32(pricetb.Text);
                    if (smartcheckbox.Checked) { tv1.smart = true; }
                    else { tv1.smart = false; }
                    tv1.size = sizetb.Text;
                    tv1.respond_time = respond_time_tb.Text;
                    string tv_data;
                    tv_data = tv1.data();
                    FileStream fs = new FileStream("tv.txt", FileMode.Append, FileAccess.Write);
                    StreamWriter sw = new StreamWriter(fs);
                    sw.WriteLine(tv_data);
                    sw.Close();
                    fs.Close();
                    MessageBox.Show("product added succesfully ");
                    type_box.ResetText();
                    idtb.Clear();
                    brandtb.Clear();
                    modeltb.Clear();
                    pricetb.Clear();
                    smartcheckbox.Checked = false;
                    sizetb.Clear();
                    respond_time_tb.Clear();
                    add_tv_box.Enabled = false;
                }


            }

            catch (Exception r) { MessageBox.Show(r.Message); };
        }

        private void add_fridge_btn_Click(object sender, EventArgs e)
        {
            try
            {
                if (idtb.Text.Length == 0) { MessageBox.Show("id should not be empty"); }
                else if (brandtb.Text.Length == 0) { MessageBox.Show("brand should not be empty"); }
                else if (modeltb.Text.Length == 0) { MessageBox.Show("model should not be empty"); }
                else if (pricetb.Text.Length == 0) { MessageBox.Show("price should not be empty"); }
                else if (capacitytb.Text.Length == 0) { MessageBox.Show("capacity should not be empty"); }
                else if (electricitytb.Text.Length == 0) { MessageBox.Show("electricity should not be empty"); }

                else
                {
                    fridge f1 = new fridge();
                    f1.id = idtb.Text;
                    f1.brand = brandtb.Text;
                    f1.model = modeltb.Text;
                    f1.price = Convert.ToInt32(pricetb.Text);
                    f1.capacity = capacitytb.Text;
                    f1.electricity = electricitytb.Text;
                    if (noise_check_box.Checked) { f1.noise = true; }
                    else { f1.noise = false; }
                    string fridge_data;
                    fridge_data = f1.data();
                    FileStream fs = new FileStream("fridge.txt", FileMode.Append, FileAccess.Write);
                    StreamWriter sw = new StreamWriter(fs);
                    sw.WriteLine(fridge_data);
                    sw.Close();
                    fs.Close();
                    MessageBox.Show("product added succesfully ");
                    type_box.ResetText();
                    idtb.Clear();
                    brandtb.Clear();
                    modeltb.Clear();
                    pricetb.Clear();
                    capacitytb.Clear();
                    electricitytb.Clear();
                    noise_check_box.Checked=false;
                    add_fridge_box.Enabled = false;
                }
               


            }
            catch (Exception r) { MessageBox.Show(r.Message); };
        }

        private void add_stove_btn_Click(object sender, EventArgs e)
        {
            try
            {
                if (idtb.Text.Length == 0) { MessageBox.Show("id should not be empty"); }
                else if (brandtb.Text.Length == 0) { MessageBox.Show("brand should not be empty"); }
                else if (modeltb.Text.Length == 0) { MessageBox.Show("model should not be empty"); }
                else if (pricetb.Text.Length == 0) { MessageBox.Show("price should not be empty"); }
                else if (number_of_heaters_tb.Text.Length == 0) { MessageBox.Show("number of heaters should not be empty"); }
                stove s1 = new stove();
                s1.id = idtb.Text;
                s1.brand = brandtb.Text;
                s1.model = modeltb.Text;
                s1.price = Convert.ToInt32(pricetb.Text);
                s1.number_of_heaters = Convert.ToInt32( number_of_heaters_tb.Text);
                if (ovencheckbox.Checked) { s1.oven = true; }
                else { s1.oven = false; }
                if (gascheckbox.Checked) { s1.gas = true; }
                else { s1.gas = false; }
                string stove_data;
                stove_data = s1.data();
                FileStream fs = new FileStream("stove.txt", FileMode.Append, FileAccess.Write);
                StreamWriter sw = new StreamWriter(fs);
                sw.WriteLine(stove_data);
                sw.Close();
                fs.Close();
                MessageBox.Show("product added succesfully ");
                type_box.ResetText();
                idtb.Clear();
                brandtb.Clear();
                modeltb.Clear();
                pricetb.Clear();
                number_of_heaters_tb.Clear();
                ovencheckbox.Checked = false;
                gascheckbox.Checked = false;
                add_stove_box.Enabled = false;

            }
            catch (Exception r) { MessageBox.Show(r.Message); };

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }
    }
}