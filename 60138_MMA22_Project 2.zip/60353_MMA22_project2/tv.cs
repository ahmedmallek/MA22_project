﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _60353_MMA22_project2
{
    class tv:product
    {
        public string size;
        public string respond_time;
        public bool smart;
        

        public string data()
        {
            return brand + "|"+model + "|"+id + "|"+ size+"|" +smart + "|" + respond_time+"|" + price;
        }
    }
}
