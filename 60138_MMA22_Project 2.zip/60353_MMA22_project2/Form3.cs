﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace _60353_MMA22_project2
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void back_btn_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            this.Hide();
            f1.ShowDialog();
            this.Close();
        }

        private void showbtn_Click(object sender, EventArgs e)
        {
            if (type_box.SelectedItem == "tv")
            {
                products_box.Items.Clear();
                FileStream fs = new FileStream("tv.txt", FileMode.Open, FileAccess.Read);
                StreamReader sr = new StreamReader(fs);
                while (!sr.EndOfStream)
                {
                    string w = sr.ReadLine();
                    int x1, x2;
                    x1 = w.IndexOf("|");
                    x2 = w.IndexOf("|", x1+1);
                    products_box.Items.Add(w.Substring(0, w.IndexOf("|")) + ":" + w.Substring(x1+1,x2-x1-1));


                }
            }
            else if (type_box.SelectedItem == "fridge")
            {
                products_box.Items.Clear();
                FileStream fs1 = new FileStream("fridge.txt", FileMode.Open, FileAccess.Read);
                StreamReader sr1 = new StreamReader(fs1);
                while (!sr1.EndOfStream)
                {
                    string w1 = sr1.ReadLine();
                    int y1, y2;
                    y1 = w1.IndexOf("|");
                    y2 = w1.IndexOf("|", y1 + 1);
                    products_box.Items.Add(w1.Substring(0, w1.IndexOf("|")) + ":" + w1.Substring(y1+1, y2 - y1 - 1));


                }
            }
            else if (type_box.SelectedItem == "stove")
            {
                products_box.Items.Clear();
                FileStream fs2 = new FileStream("stove.txt", FileMode.Open, FileAccess.Read);
                StreamReader sr2 = new StreamReader(fs2);
                while (!sr2.EndOfStream)
                {
                    string w2 = sr2.ReadLine();
                    int z1, z2;
                    z1 = w2.IndexOf("|");
                    z2 = w2.IndexOf("|", z1 + 1);
                    products_box.Items.Add(w2.Substring(0, w2.IndexOf("|")) +":"+ w2.Substring(z1+1, z2 - z1-1 ));


                }


            }
            label2.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            label6.Visible = false;
            label7.Visible = false;
            label8.Visible = false;
            label9.Visible = false;
            label10.Visible = false;
            label11.Visible = false;
            label12.Visible = false;
            label13.Visible = false;
            label14.Visible = false;
            label15.Visible = false;
            label16.Visible = false;


        }

        private void show_info_btn_Click(object sender, EventArgs e)
        {
            try {

                 if (type_box.SelectedItem == "tv")
                    {
                        FileStream fs = new FileStream("tv.txt", FileMode.Open, FileAccess.Read);
                        StreamReader sr = new StreamReader(fs);


                        while (!sr.EndOfStream)
                        {
                            string w = sr.ReadLine();
                            int x1, x2, x3, x4, x5, x6;
                            x1 = w.IndexOf("|");
                            x2 = w.IndexOf("|", x1 + 1);
                            x3 = w.IndexOf("|", x2 + 1);
                            x4 = w.IndexOf("|", x3 + 1);
                            x5 = w.IndexOf("|", x4 + 1);
                            x6 = w.IndexOf("|", x5 + 1);

                            if (products_box.SelectedItem.ToString() == w.Substring(0, w.IndexOf("|")) + ":" + w.Substring(x1 + 1, x2 - x1 - 1))

                            {
                                label13.Text = "brand:";
                                label14.Text = w.Substring(0, x1);
                                label2.Text = "model:";
                                label4.Text = w.Substring(x1 + 1, x2 - x1 - 1);
                                label5.Text = "id:";
                                label6.Text = w.Substring(x2 + 1, x3 - x2 - 1);
                                label7.Text = "size:";
                                label8.Text = w.Substring(x3 + 1, x4 - x3 - 1);
                                label9.Text = "smart:";
                                label10.Text = w.Substring(x4 + 1, x5 - x4 - 1);
                                label11.Text = "respond time:";
                                label12.Text = w.Substring(x5 + 1, x6 - x5 - 1);
                                label15.Text = "price:";
                                label16.Text = w.Substring(x6 + 1);




                            }
                        }
                        fs.Close();
                        sr.Close();
                    }
                    else if (type_box.SelectedItem == "fridge")
                    {
                        FileStream fs1 = new FileStream("fridge.txt", FileMode.Open, FileAccess.Read);
                        StreamReader sr1 = new StreamReader(fs1);


                        while (!sr1.EndOfStream)
                        {
                            string w1 = sr1.ReadLine();
                            int y1, y2, y3, y4, y5, y6;
                            y1 = w1.IndexOf("|", 0);
                            y2 = w1.IndexOf("|", y1 + 1);
                            y3 = w1.IndexOf("|", y2 + 1);
                            y4 = w1.IndexOf("|", y3 + 1);
                            y5 = w1.IndexOf("|", y4 + 1);
                            y6 = w1.IndexOf("|", y5 + 1);

                            if (products_box.SelectedItem.ToString() == w1.Substring(0, w1.IndexOf("|")) + ":" + w1.Substring(y1 + 1, y2 - y1 - 1))
                            {

                                label13.Text = "brand:";
                                label14.Text = w1.Substring(0, y1);
                                label2.Text = "model:";
                                label4.Text = w1.Substring(y1 + 1, y2 - y1 - 1);
                                label5.Text = "id:";
                                label6.Text = w1.Substring(y2 + 1, y3 - y2 - 1);
                                label7.Text = "capacity:";
                                label8.Text = w1.Substring(y3 + 1, y4 - y3 - 1);
                                label9.Text = "electricity:";
                                label10.Text = w1.Substring(y4 + 1, y5 - y4 - 1);
                                label11.Text = "noise:";
                                label12.Text = w1.Substring(y5 + 1, y6 - y5 - 1);
                                label15.Text = "price:";
                                label16.Text = w1.Substring(y6 + 1);

                            }
                        }
                        fs1.Close();
                        sr1.Close();

                    }
                    else if (type_box.SelectedItem == "stove")
                    {
                        FileStream fs2 = new FileStream("stove.txt", FileMode.Open, FileAccess.Read);
                        StreamReader sr2 = new StreamReader(fs2);


                        while (!sr2.EndOfStream)
                        {
                            string w2 = sr2.ReadLine();
                            int z1, z2, z3, z4, z5, z6;
                            z1 = w2.IndexOf("|", 0);
                            z2 = w2.IndexOf("|", z1 + 1);
                            z3 = w2.IndexOf("|", z2 + 1);
                            z4 = w2.IndexOf("|", z3 + 1);
                            z5 = w2.IndexOf("|", z4 + 1);
                            z6 = w2.IndexOf("|", z5 + 1);

                            if (products_box.SelectedItem.ToString() == w2.Substring(0, w2.IndexOf("|")) + ":" + w2.Substring(z1 + 1, z2 - z1 - 1))
                            {
                                label13.Text = "brand:";
                                label14.Text = w2.Substring(0, z1);
                                label2.Text = "model:";
                                label4.Text = w2.Substring(z1 + 1, z2 - z1 - 1);
                                label5.Text = "id:";
                                label6.Text = w2.Substring(z2 + 1, z3 - z2 - 1);
                                label7.Text = "number of heaters:";
                                label8.Text = w2.Substring(z3 + 1, z4 - z3 - 1);
                                label9.Text = "oven:";
                                label10.Text = w2.Substring(z4 + 1, z5 - z4 - 1);
                                label11.Text = "gas:";
                                label12.Text = w2.Substring(z5 + 1, z6 - z5 - 1);
                                label15.Text = "price:";
                                label16.Text = w2.Substring(z6 + 1);


                            }
                        }
                        fs2.Close();
                        sr2.Close();
                    }












                    label2.Visible = true;
                    label4.Visible = true;
                    label5.Visible = true;
                    label6.Visible = true;
                    label7.Visible = true;
                    label8.Visible = true;
                    label9.Visible = true;
                    label10.Visible = true;
                    label11.Visible = true;
                    label12.Visible = true;
                    label13.Visible = true;
                    label14.Visible = true;
                    label15.Visible = true;
                    label16.Visible = true;
                }
            catch (Exception r) { MessageBox.Show(r.Message); }

        


        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }
    }
}
