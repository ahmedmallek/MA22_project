﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _60353_MMA22_project2
{
    class fridge:product
    {
        public string capacity;
        public string electricity;
        public bool noise ;
    
        public string data()
        {
            return brand + "|" + model + "|" + id + "|" + capacity + "|" + electricity + "|" +noise+"|" + price;
        }
    }
}
