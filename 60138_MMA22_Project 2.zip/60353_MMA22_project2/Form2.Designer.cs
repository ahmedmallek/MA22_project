﻿
namespace _60353_MMA22_project2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.proceed_btn = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pricetb = new System.Windows.Forms.TextBox();
            this.brandtb = new System.Windows.Forms.TextBox();
            this.modeltb = new System.Windows.Forms.TextBox();
            this.idtb = new System.Windows.Forms.TextBox();
            this.type_box = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.add_tv_box = new System.Windows.Forms.GroupBox();
            this.add_tv_btn = new System.Windows.Forms.Button();
            this.smartcheckbox = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.respond_time_tb = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.sizetb = new System.Windows.Forms.TextBox();
            this.add_fridge_box = new System.Windows.Forms.GroupBox();
            this.add_fridge_btn = new System.Windows.Forms.Button();
            this.capacitytb = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.electricitytb = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.add_stove_box = new System.Windows.Forms.GroupBox();
            this.add_stove_btn = new System.Windows.Forms.Button();
            this.gascheckbox = new System.Windows.Forms.CheckBox();
            this.ovencheckbox = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.number_of_heaters_tb = new System.Windows.Forms.TextBox();
            this.back_btn = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.noise_check_box = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.add_tv_box.SuspendLayout();
            this.add_fridge_box.SuspendLayout();
            this.add_stove_box.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.proceed_btn);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.pricetb);
            this.groupBox1.Controls.Add(this.brandtb);
            this.groupBox1.Controls.Add(this.modeltb);
            this.groupBox1.Controls.Add(this.idtb);
            this.groupBox1.Controls.Add(this.type_box);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox1.Location = new System.Drawing.Point(22, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(762, 240);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "General informations";
            // 
            // proceed_btn
            // 
            this.proceed_btn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.proceed_btn.Location = new System.Drawing.Point(25, 176);
            this.proceed_btn.Name = "proceed_btn";
            this.proceed_btn.Size = new System.Drawing.Size(701, 46);
            this.proceed_btn.TabIndex = 10;
            this.proceed_btn.Text = "Proceed";
            this.proceed_btn.UseVisualStyleBackColor = false;
            this.proceed_btn.Click += new System.EventHandler(this.proceed_btn_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(416, 107);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 20);
            this.label5.TabIndex = 9;
            this.label5.Text = "Price : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(416, 59);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 20);
            this.label4.TabIndex = 8;
            this.label4.Text = "Brand : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(87, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "Model : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(87, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "ID :";
            // 
            // pricetb
            // 
            this.pricetb.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pricetb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pricetb.Location = new System.Drawing.Point(504, 107);
            this.pricetb.Name = "pricetb";
            this.pricetb.Size = new System.Drawing.Size(127, 27);
            this.pricetb.TabIndex = 5;
            // 
            // brandtb
            // 
            this.brandtb.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.brandtb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.brandtb.Location = new System.Drawing.Point(503, 58);
            this.brandtb.Name = "brandtb";
            this.brandtb.Size = new System.Drawing.Size(128, 27);
            this.brandtb.TabIndex = 4;
            // 
            // modeltb
            // 
            this.modeltb.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.modeltb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.modeltb.Location = new System.Drawing.Point(179, 134);
            this.modeltb.Name = "modeltb";
            this.modeltb.Size = new System.Drawing.Size(130, 27);
            this.modeltb.TabIndex = 3;
            // 
            // idtb
            // 
            this.idtb.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.idtb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idtb.Location = new System.Drawing.Point(179, 85);
            this.idtb.Name = "idtb";
            this.idtb.Size = new System.Drawing.Size(130, 27);
            this.idtb.TabIndex = 2;
            // 
            // type_box
            // 
            this.type_box.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.type_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.type_box.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.type_box.FormattingEnabled = true;
            this.type_box.Items.AddRange(new object[] {
            "tv",
            "fridge",
            "stove"});
            this.type_box.Location = new System.Drawing.Point(179, 34);
            this.type_box.Name = "type_box";
            this.type_box.Size = new System.Drawing.Size(130, 28);
            this.type_box.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(87, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Type :";
            // 
            // add_tv_box
            // 
            this.add_tv_box.BackColor = System.Drawing.Color.Transparent;
            this.add_tv_box.Controls.Add(this.add_tv_btn);
            this.add_tv_box.Controls.Add(this.smartcheckbox);
            this.add_tv_box.Controls.Add(this.label7);
            this.add_tv_box.Controls.Add(this.respond_time_tb);
            this.add_tv_box.Controls.Add(this.label6);
            this.add_tv_box.Controls.Add(this.sizetb);
            this.add_tv_box.Enabled = false;
            this.add_tv_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_tv_box.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.add_tv_box.Location = new System.Drawing.Point(20, 255);
            this.add_tv_box.Name = "add_tv_box";
            this.add_tv_box.Size = new System.Drawing.Size(246, 190);
            this.add_tv_box.TabIndex = 1;
            this.add_tv_box.TabStop = false;
            this.add_tv_box.Text = "ADD TV";
            // 
            // add_tv_btn
            // 
            this.add_tv_btn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.add_tv_btn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.add_tv_btn.Location = new System.Drawing.Point(39, 144);
            this.add_tv_btn.Name = "add_tv_btn";
            this.add_tv_btn.Size = new System.Drawing.Size(161, 36);
            this.add_tv_btn.TabIndex = 9;
            this.add_tv_btn.Text = "Add TV ";
            this.add_tv_btn.UseVisualStyleBackColor = false;
            this.add_tv_btn.Click += new System.EventHandler(this.add_tv_btn_Click);
            // 
            // smartcheckbox
            // 
            this.smartcheckbox.AutoSize = true;
            this.smartcheckbox.Location = new System.Drawing.Point(84, 109);
            this.smartcheckbox.Name = "smartcheckbox";
            this.smartcheckbox.Size = new System.Drawing.Size(74, 22);
            this.smartcheckbox.TabIndex = 8;
            this.smartcheckbox.Text = "Smart ";
            this.smartcheckbox.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 77);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(112, 18);
            this.label7.TabIndex = 7;
            this.label7.Text = "Respond time : ";
            // 
            // respond_time_tb
            // 
            this.respond_time_tb.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.respond_time_tb.Location = new System.Drawing.Point(137, 74);
            this.respond_time_tb.Name = "respond_time_tb";
            this.respond_time_tb.Size = new System.Drawing.Size(103, 24);
            this.respond_time_tb.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 38);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 18);
            this.label6.TabIndex = 5;
            this.label6.Text = "Size : ";
            // 
            // sizetb
            // 
            this.sizetb.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.sizetb.Location = new System.Drawing.Point(137, 38);
            this.sizetb.Name = "sizetb";
            this.sizetb.Size = new System.Drawing.Size(103, 24);
            this.sizetb.TabIndex = 4;
            // 
            // add_fridge_box
            // 
            this.add_fridge_box.BackColor = System.Drawing.Color.Transparent;
            this.add_fridge_box.Controls.Add(this.noise_check_box);
            this.add_fridge_box.Controls.Add(this.add_fridge_btn);
            this.add_fridge_box.Controls.Add(this.capacitytb);
            this.add_fridge_box.Controls.Add(this.label9);
            this.add_fridge_box.Controls.Add(this.electricitytb);
            this.add_fridge_box.Controls.Add(this.label10);
            this.add_fridge_box.Enabled = false;
            this.add_fridge_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_fridge_box.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.add_fridge_box.Location = new System.Drawing.Point(283, 256);
            this.add_fridge_box.Name = "add_fridge_box";
            this.add_fridge_box.Size = new System.Drawing.Size(254, 189);
            this.add_fridge_box.TabIndex = 2;
            this.add_fridge_box.TabStop = false;
            this.add_fridge_box.Text = "ADD FRIDGE";
            // 
            // add_fridge_btn
            // 
            this.add_fridge_btn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.add_fridge_btn.Location = new System.Drawing.Point(45, 143);
            this.add_fridge_btn.Name = "add_fridge_btn";
            this.add_fridge_btn.Size = new System.Drawing.Size(161, 40);
            this.add_fridge_btn.TabIndex = 15;
            this.add_fridge_btn.Text = "Add Fridge";
            this.add_fridge_btn.UseVisualStyleBackColor = false;
            this.add_fridge_btn.Click += new System.EventHandler(this.add_fridge_btn_Click);
            // 
            // capacitytb
            // 
            this.capacitytb.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.capacitytb.Location = new System.Drawing.Point(114, 37);
            this.capacitytb.Name = "capacitytb";
            this.capacitytb.Size = new System.Drawing.Size(110, 24);
            this.capacitytb.TabIndex = 14;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(18, 76);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 18);
            this.label9.TabIndex = 12;
            this.label9.Text = "Electricity :";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // electricitytb
            // 
            this.electricitytb.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.electricitytb.Location = new System.Drawing.Point(114, 76);
            this.electricitytb.Name = "electricitytb";
            this.electricitytb.Size = new System.Drawing.Size(110, 24);
            this.electricitytb.TabIndex = 10;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(18, 37);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(73, 18);
            this.label10.TabIndex = 8;
            this.label10.Text = "Capacity :";
            // 
            // add_stove_box
            // 
            this.add_stove_box.BackColor = System.Drawing.Color.Transparent;
            this.add_stove_box.Controls.Add(this.add_stove_btn);
            this.add_stove_box.Controls.Add(this.gascheckbox);
            this.add_stove_box.Controls.Add(this.ovencheckbox);
            this.add_stove_box.Controls.Add(this.label11);
            this.add_stove_box.Controls.Add(this.number_of_heaters_tb);
            this.add_stove_box.Enabled = false;
            this.add_stove_box.ForeColor = System.Drawing.Color.White;
            this.add_stove_box.Location = new System.Drawing.Point(552, 258);
            this.add_stove_box.Name = "add_stove_box";
            this.add_stove_box.Size = new System.Drawing.Size(232, 187);
            this.add_stove_box.TabIndex = 3;
            this.add_stove_box.TabStop = false;
            this.add_stove_box.Text = "ADD STOVE";
            // 
            // add_stove_btn
            // 
            this.add_stove_btn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.add_stove_btn.Location = new System.Drawing.Point(35, 141);
            this.add_stove_btn.Name = "add_stove_btn";
            this.add_stove_btn.Size = new System.Drawing.Size(161, 39);
            this.add_stove_btn.TabIndex = 11;
            this.add_stove_btn.Text = "Add Stove";
            this.add_stove_btn.UseVisualStyleBackColor = false;
            this.add_stove_btn.Click += new System.EventHandler(this.add_stove_btn_Click);
            // 
            // gascheckbox
            // 
            this.gascheckbox.AutoSize = true;
            this.gascheckbox.Location = new System.Drawing.Point(155, 100);
            this.gascheckbox.Name = "gascheckbox";
            this.gascheckbox.Size = new System.Drawing.Size(56, 21);
            this.gascheckbox.TabIndex = 10;
            this.gascheckbox.Text = "Gas";
            this.gascheckbox.UseVisualStyleBackColor = true;
            // 
            // ovencheckbox
            // 
            this.ovencheckbox.AutoSize = true;
            this.ovencheckbox.BackColor = System.Drawing.Color.Transparent;
            this.ovencheckbox.Location = new System.Drawing.Point(37, 100);
            this.ovencheckbox.Name = "ovencheckbox";
            this.ovencheckbox.Size = new System.Drawing.Size(64, 21);
            this.ovencheckbox.TabIndex = 9;
            this.ovencheckbox.Text = "Oven";
            this.ovencheckbox.UseVisualStyleBackColor = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 51);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(136, 17);
            this.label11.TabIndex = 7;
            this.label11.Text = "Number of Heaters :";
            // 
            // number_of_heaters_tb
            // 
            this.number_of_heaters_tb.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.number_of_heaters_tb.Location = new System.Drawing.Point(156, 51);
            this.number_of_heaters_tb.Name = "number_of_heaters_tb";
            this.number_of_heaters_tb.Size = new System.Drawing.Size(55, 22);
            this.number_of_heaters_tb.TabIndex = 6;
            // 
            // back_btn
            // 
            this.back_btn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.back_btn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.back_btn.Location = new System.Drawing.Point(283, 455);
            this.back_btn.Name = "back_btn";
            this.back_btn.Size = new System.Drawing.Size(239, 48);
            this.back_btn.TabIndex = 11;
            this.back_btn.Text = "Back to Menu";
            this.back_btn.UseVisualStyleBackColor = false;
            this.back_btn.Click += new System.EventHandler(this.back_btn_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label12.Location = new System.Drawing.Point(715, 486);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 17);
            this.label12.TabIndex = 12;
            this.label12.Text = "@MMA22";
            // 
            // noise_check_box
            // 
            this.noise_check_box.AutoSize = true;
            this.noise_check_box.Location = new System.Drawing.Point(61, 115);
            this.noise_check_box.Name = "noise_check_box";
            this.noise_check_box.Size = new System.Drawing.Size(87, 22);
            this.noise_check_box.TabIndex = 16;
            this.noise_check_box.Text = "do noise";
            this.noise_check_box.UseVisualStyleBackColor = true;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(807, 515);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.back_btn);
            this.Controls.Add(this.add_stove_box);
            this.Controls.Add(this.add_fridge_box);
            this.Controls.Add(this.add_tv_box);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.add_tv_box.ResumeLayout(false);
            this.add_tv_box.PerformLayout();
            this.add_fridge_box.ResumeLayout(false);
            this.add_fridge_box.PerformLayout();
            this.add_stove_box.ResumeLayout(false);
            this.add_stove_box.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox pricetb;
        private System.Windows.Forms.TextBox brandtb;
        private System.Windows.Forms.TextBox modeltb;
        private System.Windows.Forms.TextBox idtb;
        private System.Windows.Forms.ComboBox type_box;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox add_tv_box;
        private System.Windows.Forms.Button add_tv_btn;
        private System.Windows.Forms.CheckBox smartcheckbox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox respond_time_tb;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox sizetb;
        private System.Windows.Forms.GroupBox add_fridge_box;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox electricitytb;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox add_stove_box;
        private System.Windows.Forms.TextBox capacitytb;
        private System.Windows.Forms.Button proceed_btn;
        private System.Windows.Forms.Button add_fridge_btn;
        private System.Windows.Forms.Button add_stove_btn;
        private System.Windows.Forms.CheckBox gascheckbox;
        private System.Windows.Forms.CheckBox ovencheckbox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox number_of_heaters_tb;
        private System.Windows.Forms.Button back_btn;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.CheckBox noise_check_box;
    }
}